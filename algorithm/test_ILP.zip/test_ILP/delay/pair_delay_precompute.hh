#pragma once

#include "common/routing_types.hh"
#include "graph/unified_routing_graph.hh"
#include "sat/unified_sat_scope.hh"
#include "scope/pair_routing_state.hh"

#include <cstdint>
#include <stdexcept>
#include <std/collection.hh>
#include <string>
#include <utility>

namespace PR_tool {

class ScopedPathUnavailable final : public std::runtime_error {
public:
    ScopedPathUnavailable(PairKey pair_key, std::string message)
        : std::runtime_error(std::move(message)), pair_key(pair_key) {}

    PairKey pair_key;
};

struct PairDelayInfo {
    std::size_t net_id{0};
    std::size_t demand_id{0};
    std::size_t source_index{0};
    int source_node{-1};
    int sink_node{-1};
    // Allowed sink delays for constraint 3: normally {d_min}; only V18
    // Pose/Nege source trees start from {d_min, d_min+1, d_min+2}.
    // Feedback may expand either form.
    std::Vector<int> delays;
    // Maximum allowed delay after precompute.
    int target_delay{0};
    // For sync-bus members only: shortest delay before bus-wide max alignment.
    int member_shortest_delay{-1};
};

struct SourceDelayDomain {
    std::size_t net_id{0};
    std::size_t source_index{0};
    int source_node{-1};
    std::size_t scope_index{0};
    int d_max{0};
    std::uint16_t source_unit_mask{0xffff};
    std::size_t unit_eligible_node_count{0};
    std::size_t unit_eligible_tob_arc_count{0};
    // Flat [node_offset * (d_max + 1) + d] mask. True only when the state lies
    // on a structural source-to-sink walk at a currently allowed pair delay.
    std::Vector<std::uint8_t> active_d;
};

struct DelayPrecomputeResult {
    std::Vector<PairDelayInfo> pairs;
    std::Vector<SourceDelayDomain> sources;
};

auto bfs_shortest_delay(
    const UnifiedGraph& graph,
    const UnifiedSatNetScope& scope,
    int source_node,
    int sink_node
) -> int;

auto compute_pair_delays(
    const UnifiedGraph& graph,
    const std::Vector<RoutingNet>& nets,
    const std::Vector<UnifiedSatNetScope>& scopes,
    RoutingProblemState* problem_state = nullptr
) -> DelayPrecomputeResult;

auto log_delay_precompute(
    const std::Vector<RoutingNet>& nets,
    const DelayPrecomputeResult& delays,
    int verbose_level
) -> void;

} // namespace PR_tool

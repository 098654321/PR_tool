## 第十四版方法的分析

这一版方法已经可以用比较快的速度求解出来准备好的所有case，但是布线长度普遍偏长。经过检查，发现两个问题：

- 多扇出net存在非最优的布线解：在建模的时候，D变量描述了每一对（source, target）之间的连接关系，也就是把多扇出看成了多对2-pin net。虽然没有禁止这些对之间的布线路径功用一些资源形成布线树，但是每一对之间的d是单独求的，所以整个树的布线长度不是最优的。
- 当某个net失败之后，会扩展d，在delays集合中加入d_max + 1, d_max + 2。但是对于只需要d_max加1的net来说，如果允许了d_max+2，就有可能得到更长的布线结果



实际布线当中，布线长度比最短长度明显增加的net是trackstobumpsnet和tracktobumpsnet，而且常常增加超过100%，例如case7的一次布线日志：

```text
[2026-07-10 09:23:24]  INFO   > non-shortest nets: count=18
**[2026-07-10 09:23:24]  INFO   >   net="Nege nets" id=18 actual=332 shortest=89 delta=273.03%
[2026-07-10 09:23:24]  INFO   >   net="Pose nets" id=17 actual=306 shortest=89 delta=243.82%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_0_0_in_group_-1_with_4_ends" id=28 actual=54 shortest=24 delta=125.00%**
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_7_0_in_group_-1_with_4_ends" id=23 actual=47 shortest=24 delta=95.83%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_0_9_in_group_-1_with_4_ends" id=24 actual=35 shortest=22 delta=59.09%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_1_13_in_group_-1_with_4_ends" id=19 actual=38 shortest=24 delta=58.33%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_0_9_in_group_-1_with_4_ends" id=33 actual=33 shortest=22 delta=50.00%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_9_9_in_group_-1_with_4_ends" id=25 actual=34 shortest=23 delta=47.83%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_1_13_in_group_-1_with_4_ends" id=20 actual=34 shortest=24 delta=41.67%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_7_13_in_group_-1_with_4_ends" id=30 actual=35 shortest=25 delta=40.00%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_7_13_in_group_-1_with_4_ends" id=32 actual=35 shortest=25 delta=40.00%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_9_9_in_group_-1_with_4_ends" id=31 actual=31 shortest=23 delta=34.78%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_9_0_in_group_-1_with_4_ends" id=34 actual=35 shortest=26 delta=34.62%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_7_0_in_group_-1_with_4_ends" id=22 actual=31 shortest=24 delta=29.17%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_1_0_in_group_-1_with_4_ends" id=21 actual=27 shortest=22 delta=22.73%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_1_0_in_group_-1_with_4_ends" id=26 actual=26 shortest=22 delta=18.18%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_9_0_in_group_-1_with_4_ends" id=29 actual=30 shortest=26 delta=15.38%
[2026-07-10 09:23:24]  INFO   >   net="TrackToBumpsNet_from_cob_0_0_in_group_-1_with_4_ends" id=27 actual=27 shortest=24 delta=12.50%
[2026-07-10 09:23:24]  INFO   > non-shortest summary: stretched=18 / total=66
```

所以需要优化这些net的布线长度



## 第十五版方法

**在第十四版方法的基础上，增加一个基于整数线性规划的多商品流的线长优化步骤。当第十四版的方法求解成功之后，把线长偏长的net拆除，重新用这里的方法跑一遍，优化线长。这里的“线长偏长”指的是，整个net的布线长度相对于理论最短长度增加了L%以上，L是一个可以调整的参数**



### 需要继承的内容

在求解之前，需要接收第十四版方法的建模和求解结果，包括：

- 有向图建模：仍然使用第十四版建立好的有向图模型
- scope计算结果：使用第十四版方法求解成功时的对应的scope，每一个net在自己的scope范围内求解
- 布线结果：对于线长增长低于L%的net，保存布线结果作为最终的解；对于线长增长大于等于L%的net，这些net的布线结果是需要舍弃的，但是在ILP-based MCF开始之前先暂存布线结果，这里的暂存仅仅是为了把这个结果作为ILP求解器初始解



### 多扇出net的预处理：拆解

#### 多扇出 net 的 SAT-tree segment refinement

直接在完整 parent scope 上为多扇出 net 建多汇 MCF，会同时决定分支位置、各 sink 的连接与跨 net 冲突；多个 TrackToBumpsNet 或 TracksToBumpsNet 同时进入 ILP 时，变量数量和 LP relaxation 都很大。本节改用“SAT tree → 2-pin segment → ILP refine”：tree seed 直接来自已成功的第十四版 SAT 解。普通 2-pin net 与 SyncBus member 不进行本节拆解，仍使用原来的 2-pin MCF。

#### 1. 从 SAT 路径恢复有根树

对每个被选中的多扇出 parent \(p\)，收集其全部 SAT source--sink 路径。若 \(p\) 是 TracksToBumpsNet，则先将每条路径前补 SAT 实际选择的虚拟弧 \(r_p\rightarrow t\)，其中 \(t\) 是所选 physical track。将路径取并集后，从 \(r_p\) 做根可达遍历，每个非根节点只保留一条父弧，最后仅保留能到达某个原始 sink 的部分。这样得到覆盖全部原始 sink 的有向树，消除 SAT 路径 union 中可能存在的冗余环与重新汇合。

该树只用于生成 critical node、segment guide path 和 warm start；它**不**冻结后续 ILP 的实际分支位置。

#### 2. critical node 与 2-pin segment

定义 critical node 集合：

$$
C_p=\{r_p\}\cup T^{origin}_p
\cup\{v:\deg_{\mathrm{undirected}}(v)\ge3\}.
$$

critical node 只固定 segment 的端点配对，**不**要求 segment 沿 SAT tree 原来的主干。具有相交 bbox 的 sibling segment 可以在 ILP 中选择新的公共 \(x^p/y^p\) 子路径，再在新的位置分支。这样扩大共享范围并降低 parent union 线长

沿 SAT tree 中两个 critical node 之间的 degree-2 链压缩，得到有向 2-pin segment 集合 \(S_p\)：
$$
s=(a_s,b_s,\operatorname{guide}_s),\qquad a_s,b_s\in C_p.
$$

每条 SAT tree 的无向边恰好属于一个 segment。非 terminal 的 degree-1 枝先剪掉；任何原始 sink 不得被剪掉。虚拟根不计物理线长，但可作为第一个 segment 的端点。

所有 segment 按 SAT 恢复树的根到叶方向定向。因此 segment 依赖关系本身是以 \(r_p\) 为根的 DAG；这说明虽然每段只建单位流，所有原始 sink 仍由根侧的 segment 链覆盖。

#### 3. segment bbox：最小范围

先由 \(\operatorname{guide}_s\) 的物理弧覆盖的 COB 得到最小外接矩形 \(B_s^0\)。为使相邻 segment 获得重叠搜索域、允许重建比 SAT 更大的共享主干，将其上下左右四条边各外推一格。这个一格其实可以作为一个可以调整的参数，用命令行参数 -R 决定，只不过R应该是仅对拆出的 segment 生效的非负整数，默认 0。

处理完这个bbox范围之后，取其与COB阵列真实范围的交集，确保不超出真实的范围。这个交集是这一段segment使用的求解范围。注意检查这一段segment的起点/终点有没有包含在范围里面，如果没有就需要单独加入起点/终点与相关的边。



预处理结束后，普通 2-pin net 与 SyncBus member的scope仍然是SAT当中使用的scope，但是拆解出来的这些segment就有自己新的scope了。



### ILP-based MCF建模

根据上面的拆解，现在所有的直接布线对象是2-pin net，只不过来自同一个多扇出的2-pin net仍然允许相互之间路径重叠，构成一个多扇出net的路径树。

\(N\)：所有直接布线的 2-pin 对象，包含普通 2-pin 和拆出的 segment；

\(P\)：原始 net 的 parent 集合；

\(\pi(n)\in P\)：2-pin 对象 \(n\) 所属 parent。普通 2-pin 可定义 \(\pi(n)=n\)。

用$A_n$表示2-pin net n的scope内的有向边集合。\(A_p=\bigcup_{n:\pi(n)=p}A_n \)。对 TracksToBumpsNet，包含虚拟根的首个 segment 的边集只保留 \((r_p,t_p^\star)\)

对于 TracksToBumps，还需要明确：固定 SAT 选中的 candidate track，ILP阶段不再重选候选source track

\[ r_p:\text{ parent }p\text{ 的原始根},\quad T_p^{orig}:\text{ parent }p\text{ 的原始 terminal sink 集合}, \]\[ V_p:\text{ 与 }A_p\text{ 关联的物理节点集合}. \]



#### 变量定义

1. \(f^n_{ij}\in\{0,1\},\quad (i,j)\in A_n,\ n\in N\)：表示net n是否使用了有向边(i, j)。按 2-pin 对象
2. \(x^p_{ij}\in\{0,1\},\quad (i,j)\in A_p,\ p\in P\)：表示 net \(n\) 是否把有向边（i，j）选入其物理布线树。按 parent p建立
3. \(y^p_v\in\{0,1\},\quad v\in V_p,\ p\in P\)：只对 Track、Bump、HLine、VLine 建立，不对虚拟节点建立。表示 net \(n\) 是否使用物理节点 \(v\)。按 parent p建立



#### 优化目标：最小化布线总长度

$$
\min \sum_{p\in P}L_p
$$

其中：
$$
L_p=\sum_vw_vy^p_v
$$

$$
w_v=
\begin{cases}
1,&v\text{ 是 Track 或 Bump}\\
0,&v\text{ 是 HLine、VLine 或虚拟源}
\end{cases}
$$



#### 约束条件

1. 标准流守恒约束：

   - 起点发出1单位流
     $$
     \sum_{(s_n,j)\in A_n}f^n_{s_nj}
     -\sum_{(i,s_n)\in A_n}f^n_{is_n}=1
     $$

   - 终点接受1单位流
     $$
     \sum_{(i,t_n)\in A_n}f^n_{it_n}
     -\sum_{(t_n,j)\in A_n}f^n_{t_nj}=1
     $$
     
   - 其余中间节点流入=流出
   
   注意，“source/sink 无入/无出”只能施加在 parent 的原始根和原始 terminal sink 上。不能施加在每个 segment 的 source/sink 上；一个 segment 的终点可能正是下游 segment 的起点，必须允许它继续出边。
   
2. bus线等长约束

   对同一 SyncBus 的 parent 集合 \(B\subseteq P\)，有：
   $$
   L_{p_1}=L_{p_2},\quad \forall p_1,p_2\in B
   $$
   
3. 常量约束

   - 对所有物理原始 source 和原始 terminal sink，固定对应 \(y^p_v=1\)。对于 TracksToBumpsNet，虚拟根 \(r_p\) 不建立 \(y\)；仅保留 SAT 选中的 candidate track \(t_p^\star\)，并固定 \(y^p_{t_p^\star}=1\)。

   - 对所有source加入：
     $$
     \sum_{(i,r_p)\in A_p}x^p_{ir_p}=0
     $$
   
     - 对所有sink加入：
       $$
       \sum_{(t,j)\in A_p}x^p_{tj}=0, \forall{t \in T^{origin}_p}
       $$


5. 变量之间的关系
   $$
   f^n_{ij}\le x^{\pi(n)}_{ij},
   \quad (i,j)\in A_n,\qquad
   $$
   
   $$
   x^p_{ij}\le
   \sum_{\substack{n:\pi(n)=p\\(i,j)\in A_n}}f^n_{ij},
   \quad (i,j)\in A_p
   $$
   
   $$
   \sum_{(i,v)\in A_p}x^p_{iv}=y^p_v,
   \quad \forall v\neq r_p且v不是虚拟节点
   $$
   
   $$
   x^p_{ij}\le y^p_i,\qquad x^p_{ij}\le y^p_j,
   \quad (i,j)\in A_p
   $$
   
   作用是：每个已使用非根节点恰好一个父弧，因此允许从根处分叉，但不允许两条分支重新汇合；配合正流量约束，选中的子图就是以 \(r_n\) 为根、覆盖全部 sink 的有向树。
   
6. 节点占用约束：
   $$
   \sum_{p \in P}y^p_v\le 1-\bar y_v,
   \quad \forall v \notin 虚拟节点
   $$
   其中 \(\bar y_v=1\) 表示该节点已被“不重布”的已经确认布线结果的 net 占用。这样同一 net 可以在树内共享节点，不同 net 则绝不共享。

7. TOB开关使用

   对物理开关 e=\{i,j\}：
   $$
   X_e=
   \bar X_e+
   \sum_{p \in P}(x^p_{ij}+x^p_{ji})
   $$
   其中 \(\bar X_e\) 表示保留路径已经使用该开关。

   加上：
   $$
   x^p_{ij}+x^p_{ji}\le1
   $$

   $$
   X_e\le1
   $$

   每个开关只能使用一次：
   $$
   \sum_{e\in E_{BH}(b)}X_e\le1,\qquad
   \sum_{e\in E_{BH}(h)}X_e\le1
   $$

   $$
   \sum_{e\in E_{HV}(h)}X_e\le1,\qquad
   \sum_{e\in E_{HV}(v)}X_e\le1
   $$

   这里E的下标的语义可以参考第十四版当中TOB开关约束AtMostOne当中的意思。

   最后一级开关也可以参考第十四版的描述。对每个 TOB 的第k组 开关，建立\(M_{T,k}\in\{0,1\}\)：
   $$
   X_e\le M_{T,k},
   \quad e\in
   \{\{v_k,t_k\},\{v_{k+64},t_{k+64}\}\}
   $$

   $$
   X_e\le1-M_{T,k},
   \quad e\in
   \{\{v_k,t_{k+64}\},\{v_{k+64},t_k\}\}
   $$

   保留路径使用 straight/swap 开关时，上式自然会强制对应的 \(M_{T,k}\)；未使用组无需冻结。




#### 一些剪枝的方法

根据COBUnit，把不可能使用到的Unit资源排除掉



#### maze warm start

用SAT恢复树作为初始解



#### 提取与校验

从每个 parent 根出发遍历 \(x^p=1\) 的子图，再为每个原始 sink 回溯 source--sink path；PNnet 最后剥离虚拟根。只保留根可达且覆盖原始 sink 的部分，忽略独立环。

除已有的节点占用、TOB partial matching、straight/swap 和 bus 等长校验外，新增检查：

1. 每个原始 sink 恰好被 parent tree 覆盖；
2. 每个 segment 的两个端点在其单位流中连通；
3. parent 的物理非根节点恰有一条入选弧，且不存在重新汇合；
4. 不同 parent 不共享物理节点或 TOB 开关；
5. 重算的 parent union 线长与目标中的 \(y^p\) 一致。

